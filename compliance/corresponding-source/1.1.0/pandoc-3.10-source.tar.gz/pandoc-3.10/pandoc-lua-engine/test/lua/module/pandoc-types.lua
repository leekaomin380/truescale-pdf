local tasty = require 'tasty'
local system = require 'pandoc.system'
local types = require 'pandoc.types'
local Sources = types.Sources
local Version = types.Version

local assert = tasty.assert
local test = tasty.test_case
local group = tasty.test_group

return {
  group 'Sources' {
    group 'constructor' {
      test('has type `table`', function ()
        assert.are_same(type(Sources ""), 'table')
      end),
      test('accepts a single string', function ()
        assert.are_same(type(Sources('a')), 'table')
      end),
      test('accepts a list of strings', function ()
        local srcs = Sources{'first text\n', 'second text\n'}
        assert.are_equal(srcs[1].name, '')
        assert.are_equal(srcs[1].text, 'first text\n')
      end),
      test('accepts list of filepath/content tuples', function ()
        local srcs = Sources{{'test.txt', 'semi-random content'}}
        assert.are_equal(srcs[1].name, 'test.txt')
        assert.are_equal(srcs[1].text, 'semi-random content\n')
      end),
      test('accepts lists of Source-like tables', function ()
        local srcs = Sources{{name = 'test.txt', text = 'semi-random content'}}
        assert.are_equal(srcs[1].name, 'test.txt')
        assert.are_equal(srcs[1].text, 'semi-random content\n')
      end),
    },
  },

  group 'Version' {

    group 'constructor' {
      test('has type `userdata`', function ()
        assert.are_same(type(Version {2}), 'userdata')
      end),
      test('accepts list of integers', function ()
        assert.are_same(type(Version {2, 7, 3}), 'userdata')
      end),
      test('accepts a single integer', function ()
        assert.are_same(Version(5), Version {5})
      end),
      test('accepts version as string', function ()
        assert.are_same(
          Version '4.45.1',
          Version {4, 45, 1}
        )
      end),
      test('non-version string is rejected', function ()
        local success, msg = pcall(function () Version '11friends' end)
        assert.is_falsy(success)
        assert.is_truthy(tostring(msg):match('11friends'))
      end)
    },

    group 'comparison' {
      test('smaller (equal) than', function ()
        assert.is_truthy(Version {2, 58, 3} < Version {2, 58, 4})
        assert.is_falsy(Version {2, 60, 1} < Version {2, 59, 2})
        assert.is_truthy(Version {0, 14, 3} < Version {0, 14, 3, 1})
        assert.is_truthy(Version {3, 58, 3} <= Version {4})
        assert.is_truthy(Version {0, 14, 3} <= Version {0, 14, 3, 1})
      end),
      test('larger (equal) than', function ()
        assert.is_truthy(Version{2,58,3} > Version {2, 57, 4})
        assert.is_truthy(Version{2,58,3} > Version {2, 58, 2})
        assert.is_truthy(Version {0, 8} >= Version {0, 8})
        assert.is_falsy(Version {0, 8} >= Version {0, 8, 2})
      end),
      test('equality', function ()
        assert.is_truthy(Version '8.8', Version {8, 8})
      end),
      test('second argument can be a version string', function ()
        assert.is_truthy(Version '8' < '9.1')
        assert.is_falsy(Version '8.8' < '8.7')
      end),
    },

    group 'conversion to string' {
      test('converting from and to string is a noop', function ()
        local version_string = '1.19.4'
        assert.are_equal(tostring(Version(version_string)), version_string)
      end)
    },

    group 'convenience functions' {
      test('throws error if version is too old', function ()
        local actual = Version {2, 8}
        local expected = Version {2, 9}
        assert.error_matches(
          function () actual:must_be_at_least(expected) end,
          'expected version 2.9 or newer, got 2.8'
        )
      end),
      test('does nothing if expected version is older than actual', function ()
        local actual = Version '2.9'
        local expected = Version '2.8'
        actual:must_be_at_least(expected)
      end),
      test('does nothing if expected version equals to actual', function ()
        local actual = Version '2.8'
        local expected = Version '2.8'
        actual:must_be_at_least(expected)
      end)
    }
  }
}
